# Kevin Desktop Pet

A Codex-compatible desktop pet inspired by Kevin from *Overcooked 2*.

This pet package contains a video-reference-based Kevin spritesheet with a soft matte 3D style, blue collar, yellow K tag, and multiple desktop pet animation states.

## Preview

![Kevin desktop pet preview](preview.png)

## Files

```text
kevin-desktop-pet/
  pet.json
  spritesheet.webp
  README.md
```

## Install

Copy this folder into your Codex pets directory:

```text
C:\Users\<your-user>\.codex\pets\kevin
```

The final folder should contain:

```text
C:\Users\<your-user>\.codex\pets\kevin\pet.json
C:\Users\<your-user>\.codex\pets\kevin\spritesheet.webp
```

Restart Codex Desktop, then select the custom pet named `Kevin` from the desktop pet settings.

## Notes

- Spritesheet format: WebP with transparency
- Atlas size: `1536 x 1872`
- Cell size: `192 x 208`
- States include idle, drag, happy, cry, shy, and fallback app states required by Codex.

## Credits

Character inspiration: Kevin from *Overcooked 2*.

This is a fan-made desktop pet package for personal use.
